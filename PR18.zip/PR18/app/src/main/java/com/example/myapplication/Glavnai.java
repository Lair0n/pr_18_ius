package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Glavnai extends AppCompatActivity implements View.OnClickListener {
    Button btn48, btn49, btn50, btn51, btn52, btn53, btn54;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_glavnai);

        btn48 = findViewById(R.id.button);
        btn48.setOnClickListener(this);

        btn49 = findViewById(R.id.button4);
        btn49.setOnClickListener(this);

        btn50 = findViewById(R.id.button5);
        btn50.setOnClickListener(this);

        btn51 = findViewById(R.id.button6);
        btn51.setOnClickListener(this);

        btn52 = findViewById(R.id.button7);
        btn52.setOnClickListener(this);

        btn53 = findViewById(R.id.button8);
        btn53.setOnClickListener(this);

        btn54 = findViewById(R.id.button9);
        btn54.setOnClickListener(this);
    }
    @Override
    public void onClick(View v){
        if(v.getId() == R.id.button){
            startActivity(new Intent(this, MainActivity.class));
        }
        else if(v.getId() == R.id.button4){
            startActivity(new Intent(this, MainActivity2.class));
        }
        else if(v.getId() == R.id.button5){
            startActivity(new Intent(this, MainActivity3.class));
        }
        else if(v.getId() == R.id.button6){
            startActivity(new Intent(this, MainActivity4.class));
        }
        else if(v.getId() == R.id.button7){
            startActivity(new Intent(this, MainActivity5.class));
        }
        else if(v.getId() == R.id.button8){
            startActivity(new Intent(this, MainActivity6.class));
        }
        else if(v.getId() == R.id.button9){
            startActivity(new Intent(this, MainActivity7.class));
        }
    }
}